import unittest
import atomClientAPI
import StringIO, pprint
from XmlToDictBySAX import convertNodesToDict


ENTRY = """<?xml version="1.0" encoding='iso-8859-1'?>
<entry xmlns="http://purl.org/atom/ns#">
    <title>Unit Test 1</title> 
    <summary>This is what you get</summary> 
    <content type="text/html" mode="escaped" xml:lang="en-us">When you do unit testing.</content>
</entry>"""


class atomClientCreateTest(unittest.TestCase):
    def setUp(self):
        self.interface = atomClientAPI.interface()
        
    def testAuth0(self):
        header = self.interface.AtomAuthHeader("fe19c2a5f499fd4a525e9abce78cf5585f187e2a", 'Atom-Authorization: Digest realm="dive into atom", qop="atom-auth", nonce="109231"', '/news', 'POST')
        
    def testKD(self):
        self.assertEquals("fe19c2a5f499fd4a525e9abce78cf5585f187e2a", self.interface.KD(["joe", "dive into atom", "fred"]))
        
    def test0(self):
        """Do a simple create of an Entry, then do a GET to confirm
        that the Entry showed up."""
        (status, status_text, location, content) = self.interface.createEntry(ENTRY)
        print status
        print content
        self.assertEqual(status, 201, "Returned the right status code")
        self.assertNotEqual(location, None, "Returned a proper Location header")
        (status, status_text, content) = self.interface.getEntry(location)
        self.assertEqual(status, 200)
        contentDict = convertNodesToDict(StringIO.StringIO(content), 'entry', {'http://purl.org/atom/ns#' : 'at'})
        self.assertEquals(contentDict['at:title'], "Unit Test 1")
        (status, reason, content) = self.interface.deleteEntry(location)
        print "Reason = %s" % (reason, )
        self.assertEqual(status, 200)
        

if __name__ == "__main__":	
    unittest.main()		

