This is the 25-Aug-2003 release of the wxAtomClient. 

Installation:
=============
Extract all the files into a single directory


Running:
========

   python wxAtomClientApp.py


Requirements:
=============
You will need to have wxPython installed.

Change Log:
===========
This release works with the updated authentication scheme
that better utilizes the HTTP protocol.
