__author__ = "Joe Gregorio <http://bitworking.org/>"
__version__ = "Revision: 1.00"
__copyright__ = "Copyright (c) 2003 Joe Gregorio"
__license__ = """All Rights Reserved"""


from xml.sax.handler import ContentHandler
import xml.sax
from XmlToDictBySAX import convertNodesToDict
import urlparse, httplib
import pprint
import StringIO
import sha

#Change this to some better private key at your discretion
PRIVATE_KEY = "private"

class interface:
    def __init__(self):
        """If you don't pass in the introspectionURI then we automatically 
            load up the config.xml file out of the local directory and read
            the introspection URI out of there."""
        import urllib
        self.config = convertNodesToDict(file('config.xml', 'r'), 'config', {})
        introspectionURI = self.config['introspection']

        self.introspection = convertNodesToDict(urllib.urlopen(introspectionURI), 'introspection', {'http://purl.org/atom/ns#' : 'in'})
        self.nextnonce = None
        #	conn.set_debuglevel(1)     

    def KD(self, data):
        return sha.sha(":".join(data)).hexdigest()

    def parseAuthHeader(self, header, hasDigest = True):
        print "header:: %s " % (header, )
        if header == None:
            return {}
        if hasDigest:
            body = header.split("Digest ", 1)[1]
        else: 
            body = header
        parts = body.split(",")
        keyvalues = [t.split("=") for t in parts]
        pprint.pprint(keyvalues)
        return dict([(kvp[0].strip(), kvp[1].strip().replace('"', '')) for kvp in keyvalues])
 
    def getnonce(self):
        import time, sha, base64
        timestamp = str(time.time())
        return base64.encodestring("%s %s" % (timestamp, sha.new("%s:%s" % (timestamp, PRIVATE_KEY)).hexdigest())).strip()

    def AtomAuthHeader(self, atomDigest, nonce, uri, verb):
        cnonce = self.getnonce()
        A2 = sha.sha("%s:%s" % (verb, uri)).hexdigest()
        KD_Args = [self.config['atom-digest'], nonce, "00000001", cnonce, "atom-auth", A2]
        raw = ":".join(KD_Args)
        return 'Digest username="%s", realm="%s", nonce="%s", uri="%s", qop="atom-auth", nc="00000001", cnonce="%s", response="%s"' % \
        (self.config['name'], 
          self.config['realm'], 
          nonce, 
          uri, 
          cnonce,
          self.KD(KD_Args))


    def doRequest(self, server, verb, url, xml, headers):
        conn = httplib.HTTPConnection(server)
        if self.nextnonce:
            print "Running off nextnonce!!"
            headers["Atom-Authorization"] = self.AtomAuthHeader(self.config['atom-digest'], self.nextnonce, url, verb)
        conn.request(verb, url, xml, headers)
        response = conn.getresponse()
        content = response.read()
        if response.status == 447:
            AtomAuthenticate = response.getheader("Atom-Authenticate", None)
            atomAuthDict = self.parseAuthHeader(AtomAuthenticate)
            nonce = atomAuthDict['nonce']
            conn.close()
            conn2 = httplib.HTTPConnection(server)
            headers["Atom-Authorization"] = self.AtomAuthHeader(self.config['atom-digest'], nonce, url, verb)
            conn2.request(verb, url, xml, headers)
            response = conn2.getresponse()
            content = response.read()
            
        nextAuth = response.getheader('atom-authentication-info')
        print nextAuth
        self.nextnonce = self.parseAuthHeader(nextAuth, False).get('nextnonce', self.nextnonce)
        print "NextNonce = %s" % self.nextnonce
        conn.close()
        return (response, content)
        
    def createEntry(self, xml):
        """Creates an Entry. Returns a tuple of (status code, status text, the location header, the response content)
        """
        uriParts = urlparse.urlparse(self.introspection['in:create-entry'])
        (response, content) =  self.doRequest(uriParts[1], "POST", "?".join([uriParts[2], uriParts[4]]), xml, {"Content-type": 'application/x.atom+xml'})
        return (response.status, response.reason, response.status == 201 and response.getheader('location') or None, content)

    
    def getEntry(self, uri):
        """Retrieves the Atom Entry from the given URI"""
        uriParts = urlparse.urlparse(uri)
        conn = httplib.HTTPConnection(uriParts[1])
        (response, content) =  self.doRequest(uriParts[1], "GET", "?".join([uriParts[2], uriParts[4]]), None, {"Accept": 'application/x.atom+xml'})
        return (response.status, response.reason, content)
       
    def updateEntry(self, xml, uri):
        """Updates an Entry. Returns a tuple of (status code, status text, the response content)
        """
        uriParts = urlparse.urlparse(uri)
        (response, content) =  self.doRequest(uriParts[1], "PUT", "?".join([uriParts[2], uriParts[4]]), xml, {"Content-type": 'application/x.atom+xml'})
        return (response.status, response.reason, content)
    
    def deleteEntry(self, uri):
        uriParts = urlparse.urlparse(uri)
        (response, content) =  self.doRequest(uriParts[1], "DELETE", "?".join([uriParts[2], uriParts[4]]), None, {})
        return (response.status, response.reason, content)
   
    def getEntryList(self):
        return convertSearchToList(self.introspection['in:search-entries'] + "?atom-all")
    
    
class handler(ContentHandler):
    def __init__(self):
        self.results={}
        self.id = ''
        self.title = ''
        self.text = ''
        
    def startElement(self, name, attr):
        if name in ['title', 'id']:
            self.text = ''

    def endElement(self, name):
        if name == 'entry':
            self.results[self.id] = self.title
            self.title = self.id = ''
        elif name == 'id':
            self.id = self.text
        elif name == 'title':
            self.title = self.text

    def characters(self, s):
        self.text += s


def convertSearchToList(url):
    """Pull out all the <id> and <title> pairs from each Entry
       and return them in a list of pairs.
       
       file - The source of the XML can be either a file name or a file stream."""
    parser = xml.sax.make_parser()
    h = handler()
    parser.setContentHandler(h)
    parser.parse(url)
    return h.results
