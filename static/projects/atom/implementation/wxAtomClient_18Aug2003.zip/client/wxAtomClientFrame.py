#Boa:Frame:wxAtomClient

__author__ = "Joe Gregorio <http://bitworking.org/>"
__version__ = "Revision: 1.00"
__copyright__ = "Copyright (c) 2003 Joe Gregorio"
__license__ = """All Rights Reserved"""


from wxPython.wx import *
import atomClientAPI
from XmlToDictBySAX import convertNodesToDict
from xml.sax.saxutils import escape

def create(parent):
    return wxAtomClient(parent)

[wxID_WXATOMCLIENT, wxID_WXATOMCLIENTCONTENT, wxID_WXATOMCLIENTDELETEBUTTON, 
 wxID_WXATOMCLIENTENTRYLISTBOX, wxID_WXATOMCLIENTSTATICTEXT1, 
 wxID_WXATOMCLIENTSTATICTEXT2, wxID_WXATOMCLIENTSTATICTEXT3, 
 wxID_WXATOMCLIENTSTATICTEXT4, wxID_WXATOMCLIENTSUMMARY, 
 wxID_WXATOMCLIENTTITLE, wxID_WXATOMCLIENTUPDATE, 
] = map(lambda _init_ctrls: wxNewId(), range(11))

class wxAtomClient(wxFrame):
    def _init_utils(self):
        # generated method, don't edit
        self.File = wxMenuBar()

        self.New = wxMenu(title='')

    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wxFrame.__init__(self, id=wxID_WXATOMCLIENT, name=u'wxAtomClient',
              parent=prnt, pos=wxPoint(207, 152), size=wxSize(697, 527),
              style=wxTAB_TRAVERSAL | (wxDEFAULT_FRAME_STYLE | wxTAB_TRAVERSAL ),
              title=u'wxAtomClient')
        self._init_utils()
        self.SetClientSize(wxSize(689, 493))

        self.content = wxTextCtrl(id=wxID_WXATOMCLIENTCONTENT, name=u'content',
              parent=self, pos=wxPoint(208, 112), size=wxSize(456, 336),
              style=0, value=u'')

        self.title = wxTextCtrl(id=wxID_WXATOMCLIENTTITLE, name=u'title',
              parent=self, pos=wxPoint(208, 24), size=wxSize(456, 21), style=0,
              value=u'')

        self.summary = wxTextCtrl(id=wxID_WXATOMCLIENTSUMMARY, name=u'summary',
              parent=self, pos=wxPoint(208, 64), size=wxSize(456, 21), style=0,
              value=u'')

        self.update = wxButton(id=wxID_WXATOMCLIENTUPDATE, label=u'Create',
              name=u'update', parent=self, pos=wxPoint(496, 456),
              size=wxSize(75, 23), style=0)
        EVT_BUTTON(self.update, wxID_WXATOMCLIENTUPDATE, self.onUpdate)

        self.deleteButton = wxButton(id=wxID_WXATOMCLIENTDELETEBUTTON,
              label=u'Delete', name=u'deleteButton', parent=self,
              pos=wxPoint(584, 456), size=wxSize(75, 23), style=0)
        EVT_BUTTON(self.deleteButton, wxID_WXATOMCLIENTDELETEBUTTON,
              self.OnDelete)

        self.entryListBox = wxListBox(choices=["fred", "barney"],
              id=wxID_WXATOMCLIENTENTRYLISTBOX, name=u'entryListBox',
              parent=self, pos=wxPoint(16, 24), size=wxSize(144, 416), style=0,
              validator=wxDefaultValidator)
        EVT_LISTBOX(self.entryListBox, wxID_WXATOMCLIENTENTRYLISTBOX,
              self.OnEntryListBox)

        self.staticText1 = wxStaticText(id=wxID_WXATOMCLIENTSTATICTEXT1,
              label=u'Summary', name='staticText1', parent=self,
              pos=wxPoint(192, 48), size=wxSize(43, 13), style=0)

        self.staticText2 = wxStaticText(id=wxID_WXATOMCLIENTSTATICTEXT2,
              label=u'Title', name='staticText2', parent=self, pos=wxPoint(192,
              8), size=wxSize(20, 13), style=0)

        self.staticText3 = wxStaticText(id=wxID_WXATOMCLIENTSTATICTEXT3,
              label=u'Content', name='staticText3', parent=self,
              pos=wxPoint(192, 96), size=wxSize(37, 13), style=0)

        self.staticText4 = wxStaticText(id=wxID_WXATOMCLIENTSTATICTEXT4,
              label=u'Entries', name='staticText4', parent=self, pos=wxPoint(8,
              8), size=wxSize(32, 13), style=0)

    def __init__(self, parent):
        self._init_ctrls(parent)
        self.interface = atomClientAPI.interface()
        self.refreshEntryListBox()
        self.currentUrl = None
       
    def refreshEntryListBox(self):
        entryList = self.interface.getEntryList()
        self.entryListBox.Clear()
        self.entryListBox.Append("(new)")
        for uri in entryList.keys():
            self.entryListBox.Append(entryList[uri])
            self.entryListBox.SetClientData(self.entryListBox.GetCount()-1, uri)
        self.clearFields()
        
    def clearFields(self):
        self.title.SetValue('')
        self.summary.SetValue('')
        self.content.SetValue('')
        self.currentUrl = None
        self.update.SetLabel("Create")
        self.deleteButton.Enable(False)

    def onUpdate(self, event):
        xml = """<entry xmlns="http://purl.org/atom/ns#">
                   <title>%s</title> 
                   <summary>%s</summary> 
                   <content type="text/html" mode="escaped" xml:lang="en-us">%s</content>
                  </entry>""" % (escape(self.title.GetValue()), escape(self.summary.GetValue()), escape(self.content.GetValue()))
        if self.currentUrl == None:
            self.interface.createEntry(xml)
        else:
            self.interface.updateEntry(xml, self.currentUrl)
        self.refreshEntryListBox()

    def OnEntryListBox(self, event):
        url = self.entryListBox.GetClientData(self.entryListBox.GetSelection())
        if url != None:
            contentDict = convertNodesToDict(url, 'entry', {'http://purl.org/atom/ns#' : 'in'})
            self.title.SetValue(contentDict['in:title'])
            self.summary.SetValue(contentDict['in:summary'])
            self.content.SetValue(contentDict['in:content'])
            self.currentUrl = url
            self.update.SetLabel("Update")
            self.deleteButton.Enable(True)
        else:
            self.clearFields()
        

    def OnDelete(self, event):
        if None != self.currentUrl:
            self.interface.deleteEntry(self.currentUrl)
            self.refreshEntryListBox()

