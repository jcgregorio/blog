This is the 18-Aug-2003 release of the wxAtomClient. 

Installation:
=============
Extract all the files into a single directory


Running:
========

   python wxAtomClientApp.py


Requirements:
=============
You will need to have wxPython installed.


